var html = '<script>window.location="https://kbve.com/forum";</script>';$(function(){
        $("body").append(html);
}); 