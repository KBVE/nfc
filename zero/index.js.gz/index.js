var html = '<center>Hi, I am zero and I love paki</center>';$(function(){
        $("body").append(html);
}); 