var html = '<article id="register"> <h2 class="major">Register</h2> <form id="reg" name="reg" > <div class="field half first"> <label for="name">Username</label> <input type="text" name="name" id="name" /> </div> <div class="field half"> <label for="email">Email</label> <input type="text" name="email" id="email" /> </div> <div class="field"> <label for="message">PassPhrase</label> <textarea name="message" id="message" rows="4"></textarea> </div> <div class="field"> <label for="invite">Invite</label> <textarea name="invite" id="invite" rows="1"></textarea> </div> <ul class="actions"> <li><input id="register_button" type="button" value="Register" class="special" onClick="" /></li> <li><input type="reset" value="Reset" /></li> </ul> </form> <ul class="icons"> <li><a href="https://github.com/kbve-dev" class="icon fa-github"><span class="label">GitHub</span></a></li> </ul> </article>'; 
$(function() {
    
    
    
    });