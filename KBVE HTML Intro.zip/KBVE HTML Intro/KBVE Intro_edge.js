/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};
var opts = {};
var resources = [
];
var symbols = {
"stage": {
    version: "3.0.0",
    minimumCompatibleVersion: "3.0.0",
    build: "3.0.0.322",
    baseState: "Base State",
    scaleToFit: "none",
    centerStage: "none",
    initialState: "Base State",
    gpuAccelerate: false,
    resizeInstances: false,
    content: {
            dom: [
            {
                id: 'KBVE_Logo_-_K',
                type: 'image',
                rect: ['66px', '99px','417px','91px','auto', 'auto'],
                borderRadius: ["0px", "0px", "0px", "0px"],
                opacity: 1,
                fill: ["rgba(0,0,0,0)",im+"KBVE%20Logo%20-%20K.png",'0px','0px']
            },
            {
                id: 'KBVE_Logo_-_B',
                type: 'image',
                rect: ['66px', '215px','417px','91px','auto', 'auto'],
                borderRadius: ["0px", "0px", "0px", "0px"],
                opacity: 1,
                fill: ["rgba(0,0,0,0)",im+"KBVE%20Logo%20-%20B.png",'0px','0px']
            },
            {
                id: 'KBVE_Logo_-_V',
                type: 'image',
                rect: ['66px', '99px','417px','91px','auto', 'auto'],
                borderRadius: ["0px", "0px", "0px", "0px"],
                opacity: 1,
                fill: ["rgba(0,0,0,0)",im+"KBVE%20Logo%20-%20V.png",'0px','0px']
            },
            {
                id: 'KBVE_Logo_-_E',
                type: 'image',
                rect: ['66px', '215px','417px','91px','auto', 'auto'],
                borderRadius: ["0px", "0px", "0px", "0px"],
                opacity: 1,
                fill: ["rgba(0,0,0,0)",im+"KBVE%20Logo%20-%20E.png",'0px','0px']
            },
            {
                id: 'House_small',
                type: 'image',
                rect: ['66px', '145px','120px','100px','auto', 'auto'],
                fill: ["rgba(0,0,0,0)",im+"House%20%28small%29.png",'0px','0px']
            },
            {
                id: 'Gear_small',
                type: 'image',
                rect: ['101px', '190px','50px','50px','auto', 'auto'],
                borderRadius: ["0px", "0px", "0px", "0px"],
                opacity: 1,
                fill: ["rgba(0,0,0,0)",im+"Gear%20%28small%29.png",'0px','0px']
            },
            {
                id: 'Animation_By_PurpleAnt678',
                type: 'image',
                rect: ['399px', '336px','164px','92px','auto', 'auto'],
                fill: ["rgba(0,0,0,0)",im+"Animation%20By%20PurpleAnt678.png",'0px','0px']
            }],
            symbolInstances: [

            ]
        },
    states: {
        "Base State": {
            "${_Animation_By_PurpleAnt678}": [
                ["style", "top", '336px'],
                ["style", "height", '0px'],
                ["style", "opacity", '1'],
                ["style", "left", '399px'],
                ["style", "width", '0px']
            ],
            "${_KBVE_Logo_-_V}": [
                ["style", "top", '99px'],
                ["style", "height", '0px'],
                ["style", "opacity", '1'],
                ["style", "left", '66px'],
                ["style", "width", '0px']
            ],
            "${_KBVE_Logo_-_E}": [
                ["style", "top", '215px'],
                ["style", "height", '0px'],
                ["style", "opacity", '1'],
                ["style", "left", '66px'],
                ["style", "width", '0px']
            ],
            "${_KBVE_Logo_-_B}": [
                ["style", "top", '215px'],
                ["style", "height", '0px'],
                ["style", "opacity", '1'],
                ["style", "left", '66px'],
                ["style", "width", '0px']
            ],
            "${_Stage}": [
                ["color", "background-color", 'rgba(255,255,255,1)'],
                ["style", "overflow", 'hidden'],
                ["style", "height", '400px'],
                ["style", "width", '550px']
            ],
            "${_Gear_small}": [
                ["style", "top", '190px'],
                ["transform", "rotateZ", '720deg'],
                ["style", "height", '0px'],
                ["style", "opacity", '1'],
                ["style", "left", '101px'],
                ["style", "width", '0px']
            ],
            "${_House_small}": [
                ["style", "-webkit-transform-origin", [50,50], {valueTemplate:'@@0@@% @@1@@%'} ],
                ["style", "-moz-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
                ["style", "-ms-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
                ["style", "msTransformOrigin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
                ["style", "-o-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
                ["style", "bottom", 'auto'],
                ["style", "right", 'auto'],
                ["style", "left", '66px'],
                ["style", "width", '0px'],
                ["style", "top", '145px'],
                ["style", "height", '0px'],
                ["transform", "rotateZ", '180deg'],
                ["style", "opacity", '1']
            ],
            "${_KBVE_Logo_-_K}": [
                ["style", "top", '99px'],
                ["style", "height", '0px'],
                ["style", "opacity", '1'],
                ["style", "left", '66px'],
                ["style", "width", '0px']
            ]
        }
    },
    timelines: {
        "Default Timeline": {
            fromState: "Base State",
            toState: "",
            duration: 5500,
            autoPlay: true,
            timeline: [
                { id: "eid263", tween: [ "style", "${_KBVE_Logo_-_B}", "left", '66px', { fromValue: '66px'}], position: 1500, duration: 0 },
                { id: "eid257", tween: [ "style", "${_House_small}", "left", '66px', { fromValue: '66px'}], position: 3000, duration: 0 },
                { id: "eid258", tween: [ "style", "${_House_small}", "top", '145px', { fromValue: '145px'}], position: 3000, duration: 0 },
                { id: "eid274", tween: [ "transform", "${_Gear_small}", "rotateZ", '720deg', { fromValue: '720deg'}], position: 1000, duration: 0 },
                { id: "eid276", tween: [ "transform", "${_Gear_small}", "rotateZ", '0deg', { fromValue: '720deg'}], position: 3000, duration: 1000 },
                { id: "eid250", tween: [ "style", "${_KBVE_Logo_-_V}", "height", '91px', { fromValue: '0px'}], position: 0, duration: 1000 },
                { id: "eid271", tween: [ "style", "${_KBVE_Logo_-_K}", "top", '154px', { fromValue: '99px'}], position: 1500, duration: 1000 },
                { id: "eid261", tween: [ "style", "${_KBVE_Logo_-_V}", "left", '66px', { fromValue: '66px'}], position: 1500, duration: 0 },
                { id: "eid280", tween: [ "style", "${_House_small}", "opacity", '1', { fromValue: '1'}], position: 4000, duration: 0 },
                { id: "eid299", tween: [ "style", "${_House_small}", "opacity", '0', { fromValue: '1'}], position: 4500, duration: 1000 },
                { id: "eid249", tween: [ "style", "${_KBVE_Logo_-_V}", "width", '417px', { fromValue: '0px'}], position: 0, duration: 1000 },
                { id: "eid279", tween: [ "style", "${_Gear_small}", "opacity", '1', { fromValue: '1'}], position: 4000, duration: 0 },
                { id: "eid302", tween: [ "style", "${_Gear_small}", "opacity", '0', { fromValue: '1'}], position: 4500, duration: 1000 },
                { id: "eid255", tween: [ "style", "${_Gear_small}", "left", '101px', { fromValue: '101px'}], position: 3000, duration: 0 },
                { id: "eid269", tween: [ "style", "${_KBVE_Logo_-_V}", "top", '154px', { fromValue: '99px'}], position: 1500, duration: 1000 },
                { id: "eid284", tween: [ "style", "${_KBVE_Logo_-_K}", "opacity", '1', { fromValue: '1'}], position: 4000, duration: 0 },
                { id: "eid297", tween: [ "style", "${_KBVE_Logo_-_K}", "opacity", '0', { fromValue: '1'}], position: 4500, duration: 1000 },
                { id: "eid268", tween: [ "style", "${_KBVE_Logo_-_E}", "top", '154px', { fromValue: '215px'}], position: 1500, duration: 1000 },
                { id: "eid245", tween: [ "style", "${_House_small}", "width", '120px', { fromValue: '0px'}], position: 0, duration: 1000 },
                { id: "eid246", tween: [ "style", "${_House_small}", "height", '100px', { fromValue: '0px'}], position: 0, duration: 1000 },
                { id: "eid243", tween: [ "style", "${_Gear_small}", "width", '50px', { fromValue: '0px'}], position: 0, duration: 1000 },
                { id: "eid270", tween: [ "style", "${_KBVE_Logo_-_B}", "top", '154px', { fromValue: '215px'}], position: 1500, duration: 1000 },
                { id: "eid281", tween: [ "style", "${_KBVE_Logo_-_E}", "opacity", '1', { fromValue: '1'}], position: 4000, duration: 0 },
                { id: "eid301", tween: [ "style", "${_KBVE_Logo_-_E}", "opacity", '0', { fromValue: '1'}], position: 4500, duration: 1000 },
                { id: "eid273", tween: [ "transform", "${_House_small}", "rotateZ", '180deg', { fromValue: '180deg'}], position: 1000, duration: 0 },
                { id: "eid278", tween: [ "transform", "${_House_small}", "rotateZ", '0deg', { fromValue: '180deg'}], position: 3000, duration: 1000 },
                { id: "eid252", tween: [ "style", "${_KBVE_Logo_-_B}", "height", '91px', { fromValue: '0px'}], position: 0, duration: 1000 },
                { id: "eid265", tween: [ "style", "${_KBVE_Logo_-_K}", "left", '66px', { fromValue: '66px'}], position: 1500, duration: 0 },
                { id: "eid254", tween: [ "style", "${_KBVE_Logo_-_K}", "height", '91px', { fromValue: '0px'}], position: 0, duration: 1000 },
                { id: "eid318", tween: [ "style", "${_Animation_By_PurpleAnt678}", "opacity", '0', { fromValue: '1'}], position: 4500, duration: 1000 },
                { id: "eid251", tween: [ "style", "${_KBVE_Logo_-_B}", "width", '417px', { fromValue: '0px'}], position: 0, duration: 1000 },
                { id: "eid1", tween: [ "style", "${_House_small}", "-webkit-transform-origin", [50,50], { valueTemplate: '@@0@@% @@1@@%', fromValue: [50,50]}], position: 0, duration: 0 },
                { id: "eid319", tween: [ "style", "${_House_small}", "-moz-transform-origin", [50,50], { valueTemplate: '@@0@@% @@1@@%', fromValue: [50,50]}], position: 0, duration: 0 },
                { id: "eid320", tween: [ "style", "${_House_small}", "-ms-transform-origin", [50,50], { valueTemplate: '@@0@@% @@1@@%', fromValue: [50,50]}], position: 0, duration: 0 },
                { id: "eid321", tween: [ "style", "${_House_small}", "msTransformOrigin", [50,50], { valueTemplate: '@@0@@% @@1@@%', fromValue: [50,50]}], position: 0, duration: 0 },
                { id: "eid322", tween: [ "style", "${_House_small}", "-o-transform-origin", [50,50], { valueTemplate: '@@0@@% @@1@@%', fromValue: [50,50]}], position: 0, duration: 0 },
                { id: "eid316", tween: [ "style", "${_Animation_By_PurpleAnt678}", "height", '92px', { fromValue: '0px'}], position: 0, duration: 1000 },
                { id: "eid315", tween: [ "style", "${_Animation_By_PurpleAnt678}", "width", '164px', { fromValue: '0px'}], position: 0, duration: 1000 },
                { id: "eid283", tween: [ "style", "${_KBVE_Logo_-_B}", "opacity", '1', { fromValue: '1'}], position: 4000, duration: 0 },
                { id: "eid298", tween: [ "style", "${_KBVE_Logo_-_B}", "opacity", '0', { fromValue: '1'}], position: 4500, duration: 1000 },
                { id: "eid248", tween: [ "style", "${_KBVE_Logo_-_E}", "height", '91px', { fromValue: '0px'}], position: 0, duration: 1000 },
                { id: "eid253", tween: [ "style", "${_KBVE_Logo_-_K}", "width", '417px', { fromValue: '0px'}], position: 0, duration: 1000 },
                { id: "eid247", tween: [ "style", "${_KBVE_Logo_-_E}", "width", '417px', { fromValue: '0px'}], position: 0, duration: 1000 },
                { id: "eid256", tween: [ "style", "${_Gear_small}", "top", '190px', { fromValue: '190px'}], position: 3000, duration: 0 },
                { id: "eid244", tween: [ "style", "${_Gear_small}", "height", '50px', { fromValue: '0px'}], position: 0, duration: 1000 },
                { id: "eid259", tween: [ "style", "${_KBVE_Logo_-_E}", "left", '66px', { fromValue: '66px'}], position: 1500, duration: 0 },
                { id: "eid282", tween: [ "style", "${_KBVE_Logo_-_V}", "opacity", '1', { fromValue: '1'}], position: 4000, duration: 0 },
                { id: "eid300", tween: [ "style", "${_KBVE_Logo_-_V}", "opacity", '0', { fromValue: '1'}], position: 4500, duration: 1000 }            ]
        }
    }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources, opts);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-175592324");
